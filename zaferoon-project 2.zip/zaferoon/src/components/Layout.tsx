import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { ArrowLeft, BookOpen, Check, ChefHat, Heart, LayoutDashboard, Menu, ShoppingBag, Sparkles, X } from 'lucide-react';
import { useApp } from '../lib/context';
import { fa } from '../lib/utils';
import ShoppingDrawer from './ShoppingDrawer';

export function Brand({ compact = false }: { compact?: boolean }) {
  return <Link to="/" className="brand" aria-label="زعفرون، صفحه اصلی"><span className="brand-mark"><svg viewBox="0 0 48 48" fill="none" aria-hidden="true"><path d="M9 25h30c-1 11-7 17-15 17S10 36 9 25Z" fill="currentColor"/><path d="M18 19c-5-6 5-5 1-12m10 12c-5-6 5-5 1-12" stroke="#17231b" strokeWidth="2.5" strokeLinecap="round"/><path d="M12 25h24" stroke="#fff4dc" strokeWidth="2" strokeLinecap="round"/></svg></span><span className="brand-copy"><strong>زعفرون<span className="brand-dot">.</span></strong>{!compact && <small>طعمِ خوبِ خونه</small>}</span></Link>;
}
export default function Layout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { pathname, hash } = useLocation();
  const { shopping, favorites, collections, recipes, setShoppingOpen, toast } = useApp();
  useEffect(() => { setMenuOpen(false); window.scrollTo({ top: 0, behavior: 'instant' }); }, [pathname]);
  useEffect(() => { setMenuOpen(false); }, [hash]);
  useEffect(() => {
    const recipe = pathname.startsWith('/recipes/') ? recipes.find(r => r.id === pathname.split('/')[2]) : undefined;
    const collection = pathname.startsWith('/collection/') ? collections.find(c => c.id === pathname.split('/')[2]) : undefined;
    const title = recipe?.title || collection?.name || (pathname === '/saved' ? 'دستورهای ذخیره‌شده' : pathname === '/admin' ? 'پنل مدیریت' : 'مواد از تو، غذا از ما');
    document.title = `${title} | زعفرون`;
  }, [pathname, recipes, collections]);
  const count = shopping.filter(i => !i.done).length;
  return <>
    <a href="#main-content" className="skip-link">رفتن به محتوای اصلی</a>
    <header className="site-header"><div className="container header-inner"><Brand /><nav className="desktop-nav" aria-label="منوی اصلی"><NavLink to="/" end>خانه</NavLink>{collections.map(c => <NavLink key={c.id} to={`/collection/${c.id}`}>{c.id === 'iranian' ? 'ایرانی' : c.id === 'international' ? 'فرنگی' : c.name}</NavLink>)}<Link to="/#pantry">چی بپزم؟ <Sparkles size={12} /></Link></nav><div className="header-actions"><Link to="/saved" className="icon-button saved-trigger" aria-label={`دستورهای ذخیره‌شده، ${fa(favorites.length)} مورد`} title="دستورهای ذخیره‌شده"><Heart size={20} /></Link><button className="icon-button shopping-trigger" onClick={() => setShoppingOpen(true)} aria-label={`لیست خرید، ${fa(count)} مورد`}><ShoppingBag size={21} />{count > 0 && <span className="count-bubble">{fa(count)}</span>}</button><Link to="/admin" className="admin-link"><LayoutDashboard size={17} /><span>پنل مدیریت</span></Link><button className="icon-button mobile-menu-button" aria-label={menuOpen ? 'بستن منو' : 'باز کردن منو'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button></div></div>{menuOpen && <nav className="mobile-nav" aria-label="منوی موبایل"><Link to="/">خانه</Link>{collections.map(c => <Link key={c.id} to={`/collection/${c.id}`}><span aria-hidden="true">{c.icon}</span>{c.name}</Link>)}<Link to="/#pantry"><Sparkles size={16} />چی بپزم؟</Link><Link to="/#recipes"><BookOpen size={16} />همه دستورها</Link><Link to="/saved"><Heart size={16} />ذخیره‌شده‌ها</Link><Link to="/admin"><LayoutDashboard size={16} />پنل مدیریت</Link></nav>}</header>
    <main id="main-content"><Outlet /></main>
    <footer className="site-footer"><div className="container"><div className="footer-top"><div><Brand /><p>از مواد ساده، خاطره‌های خوشمزه بساز.<br />آشپزی، به سبک خودت.</p></div><div className="footer-links"><h3>یه سر بزن</h3><Link to="/#recipes"><BookOpen size={15} />همه دستورها</Link><Link to="/#pantry"><ChefHat size={15} />پیشنهاد غذا</Link><Link to="/collection/drinks"><LeafIcon />نوشیدنی‌های سبک</Link><Link to="/saved"><Heart size={15} />دستورهای ذخیره‌شده</Link></div><div className="footer-note"><span className="eyebrow">خوشمزه‌تر، هوشمندانه‌تر</span><h3>مواد کمتر هدر می‌ره،<br />حالِ خونه بهتر می‌شه.</h3><Link to="/#pantry">از آشپزخونه‌ات شروع کن <ArrowLeft size={18} /></Link></div></div><div className="footer-bottom"><span>زعفرون؛ با عشق به طعم‌های خوب <span className="orange-text">♡</span></span><span>زمان‌ها تقریبی‌اند · تصاویر نمایشی‌اند · منابع در صفحه دستور</span></div></div></footer>
    <ShoppingDrawer />{toast && <div className={`toast ${toast.type}`} role="status">{toast.type === 'success' ? <Check size={18} /> : <X size={18} />}{toast.text}</div>}
  </>;
}
function LeafIcon() { return <Sparkles size={15} />; }
