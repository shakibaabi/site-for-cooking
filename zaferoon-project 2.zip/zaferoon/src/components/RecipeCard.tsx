import { ArrowUpLeft, Check, ChefHat, Clock3, Heart, Plus, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../lib/context';
import { fa, timeText, totalTime } from '../lib/utils';
import type { Match, Recipe } from '../lib/types';

export default function RecipeCard({ recipe, match }: { recipe: Recipe; match?: Match }) {
  const { categories, ingredients, favorites, toggleFavorite } = useApp();
  const saved = favorites.includes(recipe.id);
  const names = (ids: { ingredientId: string }[]) => ids.map(i => ingredients.find(g => g.id === i.ingredientId)?.name).filter(Boolean);
  const available = names(match?.availableEssential.filter(i => !ingredients.find(g => g.id === i.ingredientId && g.group === 'basics')) || []);
  const missing = names(match?.missingEssential || []);
  return <article className={`recipe-card ${match?.ready ? 'ready-card' : ''}`}>
    <div className="recipe-image-wrap"><Link to={`/recipes/${recipe.id}`} tabIndex={-1} aria-hidden="true"><img className="recipe-image" src={recipe.image} alt={recipe.title} loading="lazy" onError={e => { if (!e.currentTarget.src.endsWith('/images/hero-persian-feast.jpg')) e.currentTarget.src = '/images/hero-persian-feast.jpg'; }} /></Link><span className="image-category">{match ? match.ready ? <><Check size={14} /> آماده پخت</> : `${fa(match.percent)}٪ مواد اصلی موجود` : categories.find(c => c.id === recipe.category)?.name}</span><button className={`save-button ${saved ? 'saved' : ''}`} onClick={() => toggleFavorite(recipe.id)} aria-label={saved ? `حذف ${recipe.title} از ذخیره‌ها` : `ذخیره ${recipe.title}`} aria-pressed={saved}><Heart size={19} fill={saved ? 'currentColor' : 'none'} /></button>{totalTime(recipe) <= 45 && <span className="quick-badge"><span>ϟ</span> سریع و خوشمزه</span>}</div>
    <div className="recipe-card-body"><Link className="recipe-title" to={`/recipes/${recipe.id}`}><h3>{recipe.title}</h3></Link><p className="recipe-subtitle">{recipe.subtitle}</p>
      {match && <div className="match-info"><p className="available-line"><Check size={14} /><span>داری: {available.slice(0, 3).join('، ') || 'مواد پایه'}{available.length > 3 && ` و ${fa(available.length - 3)} مورد دیگر`}</span></p><p className={missing.length ? 'missing-line' : 'available-line'}>{missing.length ? <Plus size={14} /> : <Check size={14} />}<span>{missing.length ? `نیاز داری: ${missing.slice(0, 2).join('، ')}${missing.length > 2 ? ` و ${fa(missing.length - 2)} مورد دیگر` : ''}` : 'همه مواد ضروری را داری!'}</span></p>{match.missingOptional.length > 0 && <small>{fa(match.missingOptional.length)} افزودنی اختیاری؛ جزئیات در دستور</small>}</div>}
      <div className="recipe-meta"><span><Clock3 size={15} />{timeText(totalTime(recipe))}</span><span><Users size={15} />{fa(recipe.servings)} نفر</span><span><ChefHat size={15} />{recipe.difficulty}</span></div>
      <Link className="card-bottom" to={`/recipes/${recipe.id}`}><span>بریم بپزیم</span><span className="card-arrow"><ArrowUpLeft size={20} /></span></Link>
    </div>
  </article>;
}
