import { useEffect, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

export function Modal({ children, title, onClose, className = '', dialogId = 'modal-title' }: { children: ReactNode; title: string; onClose: () => void; className?: string; dialogId?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose); onCloseRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const selectors = 'button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]';
    const first = ref.current?.querySelector<HTMLElement>(selectors); first?.focus();
    const keydown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onCloseRef.current();
      if (event.key !== 'Tab') return;
      const focusable = Array.from(ref.current?.querySelectorAll<HTMLElement>(selectors) || []).filter(e => e.offsetParent !== null);
      const head = focusable[0], tail = focusable[focusable.length - 1];
      if (!head) { event.preventDefault(); return; }
      if (event.shiftKey && document.activeElement === head) { event.preventDefault(); tail?.focus(); }
      else if (!event.shiftKey && document.activeElement === tail) { event.preventDefault(); head.focus(); }
    };
    document.addEventListener('keydown', keydown);
    return () => { document.body.style.overflow = overflow; document.removeEventListener('keydown', keydown); previous?.focus(); };
  }, []);
  return createPortal(<div className={`modal-backdrop ${className}`} onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="modal-panel" role="dialog" aria-modal="true" aria-labelledby={dialogId} ref={ref}><div className="modal-header"><h2 id={dialogId}>{title}</h2><button className="icon-button" aria-label="بستن" onClick={onClose}><X size={21} /></button></div>{children}</div></div>, document.body);
}
