import { Check, CheckCheck, Copy, Download, ShoppingBag, Trash2 } from 'lucide-react';
import { Modal } from './Modal';
import { useApp } from '../lib/context';
import { copyText, fa } from '../lib/utils';

export default function ShoppingDrawer() {
  const { shopping, shoppingOpen, setShoppingOpen, toggleShopping, removeShopping, clearShopping, notify } = useApp();
  if (!shoppingOpen) return null;
  const listText = () => ['لیست خرید زعفرون', '', ...shopping.map(i => `${i.done ? '✓' : '□'} ${i.name}: ${fa(i.amount, 3)} ${i.unit} (${i.sourceName})`)].join('\n');
  const copy = async () => { try { await copyText(listText()); notify('لیست خرید کپی شد.'); } catch { notify('کپی ممکن نشد؛ از دکمه دانلود استفاده کن.', 'error'); } };
  const download = () => {
    const blob = new Blob(['\ufeff' + listText()], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = 'zaferoon-shopping-list.txt'; link.click(); URL.revokeObjectURL(url);
  };
  return <Modal title="لیست خرید من" className="drawer-modal" onClose={() => setShoppingOpen(false)}><div className="drawer-content"><p className="muted drawer-description">{fa(shopping.filter(i => !i.done).length)} مورد باقی‌مانده؛ هر چی خریدی، تیک بزن.</p>{shopping.length ? <><div className="shopping-items">{shopping.map(item => <div className={`shopping-item ${item.done ? 'done' : ''}`} key={item.id}><button className="shopping-check" onClick={() => toggleShopping(item.id)} aria-label={`${item.done ? 'علامت نزده' : 'خریداری شده'}: ${item.name}`} aria-pressed={item.done}>{item.done && <Check size={16} />}</button><div><strong>{item.name}</strong><span>{fa(item.amount, 3)} {item.unit}</span><small>{item.sourceName}</small></div><button className="icon-button small danger-text" onClick={() => removeShopping(item.id)} aria-label={`حذف ${item.name}`}><Trash2 size={16} /></button></div>)}</div><button className="text-button muted" onClick={() => clearShopping(true)}><CheckCheck size={17} />پاک کردن خریداری‌شده‌ها</button><div className="drawer-footer"><button className="button primary" onClick={copy}><Copy size={17} />کپی لیست</button><button className="button secondary" onClick={download}><Download size={17} />دانلود</button></div></> : <div className="empty-state"><div className="empty-icon"><ShoppingBag size={36} /></div><h3>لیستت فعلاً خالیه</h3><p>در صفحه هر غذا، مواد کم‌دار را با یک کلیک به این لیست اضافه کن.</p><button className="button primary" onClick={() => setShoppingOpen(false)}>بریم سراغ غذاها</button></div>}<p className="storage-note">این لیست در همین مرورگر ذخیره می‌شود.</p></div></Modal>;
}
