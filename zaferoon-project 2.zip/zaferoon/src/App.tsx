import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ChefHat, LoaderCircle, RefreshCw } from 'lucide-react';
import { useApp } from './lib/context';
import Layout from './components/Layout';
import Home from './pages/Home';
import RecipePage from './pages/RecipePage';
import Saved from './pages/Saved';
import Admin from './pages/Admin';
import NotFound from './pages/NotFound';

export default function App() {
  const { loading, error, refresh } = useApp();
  if (loading || error) return <div className="app-splash"><span className="splash-icon"><ChefHat size={46} /></span><h1>زعفرون<span>.</span></h1><p>{error || 'یه آشپزخونه خوشمزه در حال آماده شدنه...'}</p>{error ? <button className="button primary" onClick={() => void refresh()}><RefreshCw size={18} />تلاش دوباره</button> : <LoaderCircle className="spin" size={25} />}</div>;
  return <BrowserRouter><Routes><Route element={<Layout />}><Route index element={<Home />} /><Route path="collection/:section" element={<Home />} /><Route path="recipes/:id" element={<RecipePage />} /><Route path="saved" element={<Saved />} /><Route path="admin" element={<Admin />} /><Route path="*" element={<NotFound />} /></Route></Routes></BrowserRouter>;
}
