import { ArrowLeft, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../lib/context';
import { fa } from '../lib/utils';
import RecipeCard from '../components/RecipeCard';
export default function Saved() {
  const { recipes, favorites } = useApp();
  const saved = recipes.filter(r => favorites.includes(r.id));
  return <section className="saved-page container"><div className="section-heading"><div><span className="eyebrow"><Heart size={16} />دفتر خوشمزه من</span><h1>دستورهای ذخیره‌شده<span className="orange-text">.</span></h1><p>{fa(saved.length)} دستور برای روزهایی که می‌خوای یه چیز خوب بپزی.</p></div><Link className="text-button" to="/#recipes">کشف غذاهای جدید <ArrowLeft size={18} /></Link></div>{saved.length ? <div className="recipe-grid">{saved.map(recipe => <RecipeCard recipe={recipe} key={recipe.id} />)}</div> : <div className="empty-state saved-empty"><div className="empty-icon"><Heart size={40} /></div><h2>جای طعم‌های محبوبت اینجاست</h2><p>روی قلب هر دستور بزن تا برای بعد نگهش داری.<br />ذخیره‌ها در همین مرورگر باقی می‌مانند.</p><Link className="button primary" to="/#recipes">بریم غذا پیدا کنیم <ArrowLeft size={18} /></Link></div>}</section>;
}
