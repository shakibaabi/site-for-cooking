import { ArrowRight, ChefHat } from 'lucide-react';
import { Link } from 'react-router-dom';
export default function NotFound() {
  return <section className="not-found container empty-state"><div className="empty-icon"><ChefHat size={42} /></div><span className="eyebrow">۴۰۴ · یه اشتباه کوچولو</span><h1>این صفحه هنوز نپخته!</h1><p>آدرس را بررسی کن یا برگرد به آشپزخونه زعفرون.</p><Link className="button primary" to="/"><ArrowRight size={18} />برگشت به خانه</Link></section>;
}
