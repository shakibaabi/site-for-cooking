import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, BookOpen, ChefHat, Eye, EyeOff, LayoutDashboard, Leaf, LoaderCircle, LockKeyhole, LogOut, Pencil, Plus, Search, ShieldCheck, Sparkles, Trash2, X } from 'lucide-react';
import { useApp } from '../lib/context';
import { session } from '../lib/session';
import { api, ApiError } from '../lib/api';
import { fa, normalize, timeText, totalTime } from '../lib/utils';
import type { Recipe, RecipeInput } from '../lib/types';
import RecipeEditor from '../components/RecipeEditor';
import { Modal } from '../components/Modal';

export default function Admin() {
  const { recipes, categories, ingredients, refresh, notify, demo } = useApp();
  const [user, setUser] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [editor, setEditor] = useState<Recipe | 'new' | null>(null);
  const [deleting, setDeleting] = useState<Recipe | null>(null);
  const [deleteError, setDeleteError] = useState('');
  useEffect(() => {
    if (!session.getItem('zaferoon-token')) { setChecking(false); return; }
    void api<{ username: string }>('/auth/me').then(data => setUser(data.username)).catch(() => session.removeItem('zaferoon-token')).finally(() => setChecking(false));
  }, []);
  const login = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setLoginError('');
    try { const data = await api<{ username: string; token: string }>('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) }); session.setItem('zaferoon-token', data.token); setUser(data.username); setPassword(''); notify('به آشپزخونه مدیریت خوش اومدی!'); }
    catch (e) { setLoginError(e instanceof Error ? e.message : 'ورود انجام نشد.'); }
    finally { setBusy(false); }
  };
  const logout = async () => {
    try { await api('/auth/logout', { method: 'POST' }); } catch { /* Always remove local session. */ }
    session.removeItem('zaferoon-token'); setUser(null); setEditor(null); setDeleting(null); notify('از پنل خارج شدی.');
  };
  const save = async (data: RecipeInput) => {
    try {
      const isNew = editor === 'new';
      await api(isNew ? '/recipes' : `/recipes/${(editor as Recipe).id}`, { method: isNew ? 'POST' : 'PUT', body: JSON.stringify(data) });
      await refresh(); setEditor(null); notify(isNew ? 'دستور جدید اضافه شد.' : 'تغییرات دستور ذخیره شد.');
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) { setUser(null); setEditor(null); notify('نشست منقضی شده؛ دوباره وارد شو.', 'error'); }
      throw e;
    }
  };
  const confirmDelete = async () => {
    if (!deleting) return; setBusy(true); setDeleteError('');
    try { await api(`/recipes/${deleting.id}`, { method: 'DELETE' }); await refresh(); setDeleting(null); notify('دستور حذف شد.'); }
    catch (e) { setDeleteError(e instanceof Error ? e.message : 'حذف انجام نشد.'); if (e instanceof ApiError && e.status === 401) { setUser(null); setDeleting(null); } }
    finally { setBusy(false); }
  };
  if (checking) return <div className="page-loader"><LoaderCircle className="spin" /><p>بررسی دسترسی...</p></div>;
  if (!user) return <section className="login-page container"><div className="login-story"><span className="eyebrow"><ShieldCheck size={18} />آشپزخونه پشت صحنه</span><h1>طعم‌های خوب،<br />از اینجا شروع می‌شن<span className="orange-text">.</span></h1><p>دستورهای غذایی را اضافه کن، مواد و مراحل را دقیق بنویس و سفره زعفرون را خوشمزه‌تر کن.</p><div className="login-story-art"><ChefHat size={144} strokeWidth={1.1} /><Sparkles size={34} /></div><Link className="text-button" to="/">برگشت به سایت <ArrowLeft size={17} /></Link></div><div className="login-card"><span className="login-icon"><LockKeyhole size={26} /></span><h2>ورود به پنل مدیریت</h2><p>برای مدیریت دستورها وارد حساب مدیر شو.</p><form onSubmit={e => void login(e)}><label className="field">نام کاربری<input required dir="ltr" autoComplete="username" placeholder="Username" maxLength={100} value={username} onChange={e => setUsername(e.target.value)} /></label><label className="field">رمز عبور<div className="password-field"><input required dir="ltr" autoComplete="current-password" type={visible ? 'text' : 'password'} placeholder="Password" maxLength={200} value={password} onChange={e => setPassword(e.target.value)} /><button type="button" aria-label={visible ? 'پنهان کردن رمز' : 'نمایش رمز'} onClick={() => setVisible(!visible)}>{visible ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></label>{loginError && <p className="form-error" role="alert">{loginError}</p>}<button disabled={busy} type="submit" className="button primary login-submit">{busy ? <LoaderCircle className="spin" size={18} /> : <ArrowLeft size={18} />}{busy ? 'در حال ورود...' : 'ورود به مدیریت'}</button></form>{demo && <div className="demo-credentials"><span><Sparkles size={16} />حساب دمو برای امتحان کردن</span><div><span>نام کاربری: <code>admin</code></span><span>رمز: <code>demo12345</code></span></div><button className="text-button" onClick={() => { setUsername('admin'); setPassword('demo12345'); }}>استفاده از حساب دمو <ArrowLeft size={14} /></button><small>نسخه نمایشی است؛ پیش از انتشار رمز مدیر را تغییر بده.</small></div>}</div></section>;
  const filtered = recipes.filter(r => (category === 'all' || r.category === category) && (!search || normalize(r.title).includes(normalize(search))));
  return <section className="admin-page container"><div className="admin-page-heading"><div><span className="eyebrow"><LayoutDashboard size={17} />پنل مدیریت زعفرون</span><h1>سلام، سرآشپز<span className="orange-text">!</span></h1><p>همه دستورهای خوشمزه، یک جا زیر دست تو.</p></div><div><span className="admin-user"><ShieldCheck size={16} />{user}</span><button className="button secondary logout-button" onClick={() => void logout()}><LogOut size={17} />خروج</button></div></div><div className="admin-stats"><div><span className="stat-icon"><BookOpen size={24} /></span><div><strong>{fa(recipes.length)}</strong><span>دستور غذایی</span></div></div><div><span className="stat-icon"><Leaf size={24} /></span><div><strong>{fa(ingredients.length)}</strong><span>ماده اولیه قابل انتخاب</span></div></div><div><span className="stat-icon"><ChefHat size={24} /></span><div><strong>{fa(categories.length)}</strong><span>دسته‌بندی</span></div></div><div><span className="stat-icon"><Sparkles size={24} /></span><div><strong>{fa(recipes.filter(r => r.featured).length)}</strong><span>دستور ویژه</span></div></div></div><div className="admin-recipes-panel"><div className="admin-panel-heading"><div><h2>مدیریت دستورهای غذایی</h2><span>{fa(filtered.length)} دستور {search ? 'پیدا شد' : 'در این لیست'}</span></div><button className="button primary" onClick={() => setEditor('new')}><Plus size={18} />دستور جدید</button></div><div className="admin-filters"><label className="search-field"><Search size={18} /><input value={search} onChange={e => setSearch(e.target.value)} aria-label="جست‌وجوی دستورها در پنل" placeholder="جست‌وجوی نام غذا..." />{search && <button onClick={() => setSearch('')} aria-label="پاک کردن جست‌وجو"><X size={15} /></button>}</label><select value={category} onChange={e => setCategory(e.target.value)} aria-label="فیلتر دسته‌بندی مدیریت"><option value="all">همه دسته‌بندی‌ها</option>{categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>غذا</th><th>دسته‌بندی</th><th>زمان کل</th><th>نفرات</th><th>عملیات</th></tr></thead><tbody>{filtered.map(recipe => <tr key={recipe.id}><td><div className="admin-food"><img src={recipe.image} alt="" loading="lazy" /><div><Link to={`/recipes/${recipe.id}`}>{recipe.title}</Link><small>{recipe.difficulty}{recipe.featured && <span>· ویژه</span>}</small></div></div></td><td><span className="table-category">{categories.find(c => c.id === recipe.category)?.name}</span></td><td>{timeText(totalTime(recipe))}</td><td>{fa(recipe.servings)} نفر</td><td><div className="table-actions"><Link to={`/recipes/${recipe.id}`} className="icon-button small" aria-label={`مشاهده ${recipe.title}`}><Eye size={17} /></Link><button className="icon-button small" onClick={() => setEditor(recipe)} aria-label={`ویرایش ${recipe.title}`}><Pencil size={17} /></button><button className="icon-button small danger-text" onClick={() => { setDeleteError(''); setDeleting(recipe); }} aria-label={`حذف ${recipe.title}`}><Trash2 size={17} /></button></div></td></tr>)}</tbody></table>{filtered.length === 0 && <div className="empty-state"><Search size={32} /><h3>دستوری در این لیست نیست</h3><p>جست‌وجو را تغییر بده یا یک دستور جدید بساز.</p></div>}</div><div className="admin-panel-bottom"><ShieldCheck size={15} /><span>تغییرات در سرور ذخیره می‌شوند و با بارگذاری مجدد باقی می‌مانند.</span></div></div>
    {editor && <RecipeEditor recipe={editor === 'new' ? undefined : editor} onClose={() => setEditor(null)} onSave={save} />}
    {deleting && <Modal title="حذف دستور غذایی" className="delete-modal" onClose={() => { if (!busy) setDeleting(null); }}><div className="delete-content"><span className="delete-icon"><Trash2 size={30} /></span><h3>«{deleting.title}» حذف بشه؟</h3><p>این دستور از سایت و پیشنهادهای غذا حذف می‌شود. این کار قابل برگشت نیست.</p>{deleteError && <p className="form-error" role="alert">{deleteError}</p>}<div><button className="button secondary" disabled={busy} onClick={() => setDeleting(null)}>نه، نگهش دار</button><button className="button danger" disabled={busy} onClick={() => void confirmDelete()}>{busy ? <LoaderCircle className="spin" size={17} /> : <Trash2 size={17} />}بله، حذف کن</button></div></div></Modal>}
  </section>;
}
