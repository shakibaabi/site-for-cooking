import type { Ingredient, Match, Recipe } from './types';

export const fa = (value: number, decimals = 0) => new Intl.NumberFormat('fa-IR', { maximumFractionDigits: decimals }).format(value);
export const normalize = (value = '') => value.toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200c\u200d\u0640]/g, '').replace(/\s+/g, '').trim();
export const totalTime = (recipe: Recipe) => recipe.prepTime + recipe.cookTime + (recipe.restTime || 0);
export const timeText = (minutes: number) => `${fa(minutes)} دقیقه`;
export const durationText = (minutes: number) => minutes >= 60 ? `${fa(Math.floor(minutes / 60))} ساعت${minutes % 60 ? ` و ${fa(minutes % 60)} دقیقه` : ''}` : timeText(minutes);
export const scaledAmount = (amount: number, servings: number, base: number) => fa(amount * servings / base, 3);

export function evaluate(recipe: Recipe, pantry: string[], ingredients: Ingredient[], assumeBasics: boolean): Match {
  const basicIds = ingredients.filter(i => i.group === 'basics').map(i => i.id);
  const available = new Set([...pantry, ...(assumeBasics ? basicIds : ['water'])]);
  const required = recipe.ingredients.filter(i => i.essential);
  const core = required.filter(i => !basicIds.includes(i.ingredientId));
  const coreMatched = core.filter(i => available.has(i.ingredientId));
  const missingEssential = required.filter(i => !available.has(i.ingredientId));
  return {
    availableEssential: required.filter(i => available.has(i.ingredientId)), missingEssential,
    missingOptional: recipe.ingredients.filter(i => !i.essential && !available.has(i.ingredientId)),
    percent: core.length ? Math.round(coreMatched.length / core.length * 100) : 100,
    matchedCore: coreMatched.length, ready: missingEssential.length === 0,
  };
}

export async function copyText(text: string) {
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
  const element = document.createElement('textarea');
  element.value = text; element.style.position = 'fixed'; element.style.opacity = '0';
  document.body.appendChild(element); element.select();
  const successful = document.execCommand('copy'); element.remove();
  if (!successful) throw new Error('کپی نشد');
}
