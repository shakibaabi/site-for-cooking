import { session } from './session';
export class ApiError extends Error {
  constructor(message: string, public status: number, public details: string[] = []) { super(message); }
}
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = session.getItem('zaferoon-token');
  const headers = new Headers(options.headers);
  if (!(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const response = await fetch(`/api${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && path !== '/auth/login') session.removeItem('zaferoon-token');
    throw new ApiError(data.error || 'ارتباط با سرور برقرار نشد.', response.status, data.details);
  }
  return data as T;
}
