export type Ingredient = { id: string; name: string; emoji: string; group: string };
export type Category = { id: string; name: string; icon: string; section: string };
export type Collection = { id: string; name: string; icon: string; tagline: string; description: string };
export type RecipeIngredient = { ingredientId: string; amount: number; unit: string; essential: boolean; note: string };
export type RecipeStep = { title: string; text: string };
export type Recipe = {
  id: string; title: string; subtitle: string; description: string; category: string;
  section: string; restTime: number; sourceName: string; sourceUrl: string; sourceNote: string;
  tags: string[]; image: string; prepTime: number; cookTime: number; servings: number;
  difficulty: 'آسان' | 'متوسط' | 'حرفه‌ای'; featured: boolean;
  ingredients: RecipeIngredient[]; steps: RecipeStep[]; tips: string;
};
export type RecipeInput = Omit<Recipe, 'id'>;
export type Match = {
  availableEssential: RecipeIngredient[]; missingEssential: RecipeIngredient[];
  missingOptional: RecipeIngredient[]; percent: number; matchedCore: number; ready: boolean;
};
export type MatchedRecipe = Recipe & { match: Match };
export type ShoppingItem = {
  id: string; ingredientId: string; name: string; amount: number; unit: string;
  sourceId: string; sourceName: string; done: boolean;
};
export type Bootstrap = { ingredients: Ingredient[]; categories: Category[]; collections: Collection[]; recipes: Recipe[]; demo: boolean };
