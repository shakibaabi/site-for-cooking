// Some mobile/embedded browsers block Web Storage. Keep the current tab usable
// with an in-memory fallback; this is not cross-device account persistence.
const memory = new Map<string, string>();
export const session = {
  getItem(key: string): string | null {
    try { return sessionStorage.getItem(key) ?? memory.get(key) ?? null; }
    catch { return memory.get(key) ?? null; }
  },
  setItem(key: string, value: string): void {
    memory.set(key, value);
    try { sessionStorage.setItem(key, value); } catch { /* Restricted iframe. */ }
  },
  removeItem(key: string): void {
    memory.delete(key);
    try { sessionStorage.removeItem(key); } catch { /* Restricted iframe. */ }
  },
};
