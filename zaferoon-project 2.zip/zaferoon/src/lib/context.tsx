import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { api } from './api';
import type { Bootstrap, Recipe, RecipeIngredient, ShoppingItem } from './types';

function useLocal<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(key) || 'null');
      if (stored === null || (Array.isArray(initial) && !Array.isArray(stored)) || typeof stored !== typeof initial) return initial;
      return stored as T;
    } catch { return initial; }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* Private browsing/storage limit. */ } }, [key, value]);
  return [value, setValue] as const;
}

type ContextValue = Bootstrap & {
  loading: boolean; error: string; refresh: () => Promise<void>;
  pantry: string[]; toggleIngredient: (id: string) => void; clearPantry: () => void;
  assumeBasics: boolean; setAssumeBasics: (v: boolean) => void;
  favorites: string[]; toggleFavorite: (id: string) => void;
  shopping: ShoppingItem[]; shoppingOpen: boolean; setShoppingOpen: (v: boolean) => void;
  addShopping: (recipe: Recipe, rows: RecipeIngredient[], servings: number) => void;
  toggleShopping: (id: string) => void; removeShopping: (id: string) => void; clearShopping: (doneOnly?: boolean) => void;
  notify: (text: string, type?: 'success' | 'error') => void;
  toast: { text: string; type: 'success' | 'error' } | null;
};
const Context = createContext<ContextValue | null>(null);
export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Bootstrap>({ recipes: [], ingredients: [], categories: [], collections: [], demo: false });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pantry, setPantry] = useLocal<string[]>('zaferoon-pantry', []);
  const [assumeBasics, setAssumeBasics] = useLocal('zaferoon-basics', true);
  const [favorites, setFavorites] = useLocal<string[]>('zaferoon-favorites', []);
  const [shopping, setShopping] = useLocal<ShoppingItem[]>('zaferoon-shopping', []);
  const [shoppingOpen, setShoppingOpen] = useState(false);
  const [toast, setToast] = useState<ContextValue['toast']>(null);
  const toastTimeout = useRef<ReturnType<typeof setTimeout>>();
  const notify = useCallback((text: string, type: 'success' | 'error' = 'success') => {
    clearTimeout(toastTimeout.current); setToast({ text, type });
    toastTimeout.current = setTimeout(() => setToast(null), 4000);
  }, []);
  useEffect(() => () => clearTimeout(toastTimeout.current), []);
  const refresh = useCallback(async () => {
    setError('');
    try { const result = await api<Bootstrap>('/bootstrap'); setData(result); }
    catch (e) { setError(e instanceof Error ? e.message : 'سایت بارگذاری نشد.'); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  const toggleIngredient = (id: string) => setPantry(old => old.includes(id) ? old.filter(v => v !== id) : [...old, id]);
  const toggleFavorite = (id: string) => {
    const exists = favorites.includes(id);
    setFavorites(old => old.includes(id) ? old.filter(v => v !== id) : [...old, id]);
    notify(exists ? 'دستور از ذخیره‌شده‌ها برداشته شد.' : 'دستور به ذخیره‌شده‌ها اضافه شد.');
  };
  const addShopping = (recipe: Recipe, rows: RecipeIngredient[], servings: number) => {
    if (!rows.length) { notify('همه مواد ضروری را داری. وقت آشپزیه!'); return; }
    setShopping(old => {
      const next = [...old];
      rows.filter(row => row.ingredientId !== 'water').forEach(row => {
        const id = `${recipe.id}:${row.ingredientId}`;
        const value: ShoppingItem = { id, ingredientId: row.ingredientId, name: data.ingredients.find(i => i.id === row.ingredientId)?.name || row.ingredientId, amount: row.amount * servings / recipe.servings, unit: row.unit, sourceId: recipe.id, sourceName: recipe.title, done: false };
        const index = next.findIndex(i => i.id === id);
        if (index >= 0) next[index] = value; else next.push(value);
      });
      return next;
    });
    notify('مواد مورد نیاز به لیست خرید اضافه شد.'); setShoppingOpen(true);
  };
  return <Context.Provider value={{ ...data, loading, error, refresh, pantry, toggleIngredient, clearPantry: () => setPantry([]), assumeBasics, setAssumeBasics, favorites, toggleFavorite, shopping, shoppingOpen, setShoppingOpen, addShopping, toggleShopping: id => setShopping(old => old.map(i => i.id === id ? { ...i, done: !i.done } : i)), removeShopping: id => setShopping(old => old.filter(i => i.id !== id)), clearShopping: doneOnly => setShopping(old => doneOnly ? old.filter(i => !i.done) : []), notify, toast }}>{children}</Context.Provider>;
}
export function useApp() { const value = useContext(Context); if (!value) throw new Error('Missing AppProvider'); return value; }
