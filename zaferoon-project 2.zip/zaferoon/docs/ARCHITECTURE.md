# معماری، قرارداد API و مسیر توسعه

## نمای کلی

مرورگر ← React Router + Context ← REST API هم‌مبدأ ← Express ← domain validation/matching ← RecipeRepository ← JSON.

در dev، Vite در حالت middleware به سرور HTTP مشترک وصل است؛ HMR و API از همان origin استفاده می‌کنند. در production، Express پوشه `dist` و route fallback را سرو می‌کند. درخواست‌های مرورگر آدرس نسبی `/api/...` دارند و هیچ آدرس localhost در کد frontend تعبیه نشده است.

## API عمومی

| روش | مسیر | خروجی |
|---|---|---|
| GET | `/api/health` | وضعیت و mode |
| GET | `/api/bootstrap` | recipes، ingredients، categories، collections و demo flag |
| GET | `/api/recipes?q=&category=&section=` | دستورهای فیلترشده |
| GET | `/api/recipes/:id` | دستور کامل یا 404 |
| POST | `/api/suggestions` | دستورها + match مرتب‌شده |

نمونه ورودی پیشنهاد:

```json
{"pantry":["egg","tomato"],"assumeBasics":true,"maxMissing":2}
```

`maxMissing` اختیاری است. اطلاعات `match` شامل `availableEssential`, `missingEssential`, `missingOptional`, `percent`, `matchedCore`, `ready` است.

## API مدیریت

| روش | مسیر | ورودی/رفتار |
|---|---|---|
| POST | `/api/auth/login` | username/password؛ توکن تصادفی ۲۵۶ بیتی |
| GET | `/api/auth/me` | بررسی نشست |
| POST | `/api/auth/logout` | ابطال توکن |
| POST | `/api/recipes` | RecipeInput معتبر؛ ساخت UUID |
| PUT | `/api/recipes/:id` | جایگزینی اطلاعات دستور، حفظ شناسه |
| DELETE | `/api/recipes/:id` | حذف پایدار |
| POST | `/api/uploads` | multipart، فیلد `image`، حداکثر ۶ MB |

به‌جز login، API مدیریت به هدر زیر نیاز دارد:

```text
Authorization: Bearer <token>
```

دستور شامل `title`, `subtitle`, `description`, `section`, `category`, `tags`, `image`, `prepTime`, `cookTime`, `restTime`, `servings`, `difficulty`, `featured`, `ingredients`, `steps`, `tips`, `sourceName`, `sourceUrl`, `sourceNote` است. مقدار ماده همیشه عدد مثبت همراه با واحد است؛ اقلام ضروری از اختیاری جدا هستند. واحدها در frontend ویرایشگر از مجموعه آماده انتخاب می‌شوند ولی API واحد متنی کوتاه معتبر را هم می‌پذیرد.

## امنیت و محدودیت‌ها

- احراز هویت Bearer عمداً وابسته به کوکی نیست تا در live preview/iframe نیز کار کند. توکن در `sessionStorage` است و با بستن tab/ابطال نشست حذف می‌شود.
- رمز مدیر از environment دریافت و هنگام startup با bcrypt هش می‌شود. رمز ثابت دمو فقط در dev مجاز است.
- rate limit ورود: ۱۰ تلاش در ۱۵ دقیقه برای هر IP. در چند نمونه سرور، این Map باید با Redis یا سرویس مشترک جایگزین شود.
- Zod داده‌های ورودی را بررسی می‌کند؛ گروه و بخش باید هم‌خوان باشند، ماده تکراری و مقدار نامعتبر رد می‌شوند.
- تصویر ورودی فقط مسیر امن `/images/...` یا URL از نوع HTTPS است؛ source link نیز فقط HTTPS است.
- آپلود فقط با ورود، محدودیت حجم و تشخیص امضای JPG/PNG/WebP انجام می‌شود؛ SVG و HTML پذیرفته نمی‌شوند.
- `X-Content-Type-Options: nosniff` و Referrer-Policy تنظیم شده‌اند. CORS عمومی فعال نیست.
- قبل از production، CSP متناسب با دامنه تصاویر و HTTPS تنظیم شود. اسکن/بازرمزگذاری واقعی فایل تصویر، لاگ audit و session store مشترک از بهبودهای توصیه‌شده‌اند.
- این دمو برای یک مدیر طراحی شده، RBAC یا چند مدیر ندارد.

## جایگزینی Repository

متدهای `list`, `find`, `create`, `update`, `remove` در `server/repository.js` تنها مرز ذخیره‌سازی هستند. برای SQLite/PostgreSQL همین قرارداد را نگه دارید؛ routeها در صورت async شدن Repository باید await شوند.

طرح پیشنهادی SQL:

- recipes(id, section, category, title, description, timing, servings, source metadata)
- recipe_ingredients(recipe_id, ingredient_id, amount, unit, essential, note)
- recipe_steps(recipe_id, position, title, text)
- ingredients(id, name, group)
- recipe_tags(recipe_id, tag)
- users / sessions / favorites / pantry برای حساب‌های عمومی آینده

JSON فعلی از نوشتن اتمیک استفاده می‌کند اما transaction/locking میان چند process ندارد؛ برای استقرار چند worker مناسب نیست.

## اضافه کردن بخش و ماده جدید

1. بخش را به `collections` و دسته را با section صحیح به `categories` در seed اضافه کنید.
2. ماده را با شناسه ثابت به `ingredients` اضافه کنید.
3. اگر Store قبلاً ساخته شده، migration/افزودن محتوا انجام دهید؛ seed خودکار داده‌های موجود را overwrite نمی‌کند.
4. منو، صفحات بخش و selectهای مدیریت از bootstrap ساخته می‌شوند و تغییرات کاتالوگ را می‌خوانند.
5. قراردادهای TypeScript، Zod و تست‌ها را در تغییرات شکستن قرارداد، هم‌زمان به‌روز کنید.

## state مرورگر

Context داده bootstrap را نگه می‌دارد. `localStorage` برای pantry، basics assumption، favorites و shopping است. Cooking steps فقط در حافظه صفحه‌اند. اطلاعات مدیر/اعتبارنامه‌ها به localStorage نوشته نمی‌شوند. هر بار ذخیره مدیریت، bootstrap دوباره از سرور خوانده می‌شود.

## دسترس‌پذیری و موبایل

RTL و زبان fa در root، فونت محلی، دکمه‌های semantic، label ورودی‌ها، focus-visible، focus trap و Escape در مودال‌ها، aria-pressed در انتخاب‌ها و reduced-motion وجود دارند. table مدیریت در موبایل اسکرول افقی داخلی دارد؛ صفحه کلی نباید اسکرول افقی داشته باشد. حداقل عرض هدف ۳۲۰px است.

## تست‌ها

تست‌های node:test کاتالوگ، matching، validation و persistence را بررسی می‌کنند. Playwright مسیرهای انتخاب چند ماده، فیلتر، منوهای موبایل، مقدار نفرات، ذخیره و لیست خرید و یک چرخه CRUD مدیریت را پوشش می‌دهد. داده آزمایش در پایان پاک می‌شود. قبل از تغییر الگوریتم، تست‌های frontend parity را نیز اجرا کنید.
