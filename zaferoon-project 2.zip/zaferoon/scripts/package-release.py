#!/usr/bin/env python3
"""Package the complete source + compiled demo without dependencies or secrets."""
from pathlib import Path
import zipfile
import hashlib

root = Path(__file__).resolve().parents[1]
output = root.parent / 'zaferoon-project.zip'
excluded_dirs = {'node_modules', '.git', '.cache', '.npm', '__pycache__', 'test-results', 'playwright-report'}
excluded_names = {'.env', 'tsconfig.tsbuildinfo', '.DS_Store'}
for required in ['README.md', 'package-lock.json', 'src/main.tsx', 'server/index.js', 'dist/index.html']:
    if not (root / required).exists(): raise SystemExit(f'Missing {required}; run npm run build first.')
count = 0
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(root.rglob('*')):
        if not file.is_file() or file.is_symlink(): continue
        relative = file.relative_to(root)
        if any(part in excluded_dirs for part in relative.parts): continue
        if (file.name.startswith('.env') and file.name != '.env.example') or file.name in excluded_names or file.name.endswith(('.log', '.tsbuildinfo', '.tmp')): continue
        if relative.as_posix() == 'data/store.json': continue
        if ('uploads' in relative.parts) and file.name != '.gitkeep': continue
        archive.write(file, f'zaferoon/{relative.as_posix()}')
        count += 1
with zipfile.ZipFile(output) as archive:
    bad = archive.testzip()
    if bad: raise SystemExit(f'Archive integrity failed: {bad}')
print(f'Created {output.name}: {count} files, {output.stat().st_size / 1024 / 1024:.2f} MB')
print('SHA256:', hashlib.sha256(output.read_bytes()).hexdigest())
