import { test, expect } from '@playwright/test';
import { Buffer } from 'node:buffer';

const adminUser = process.env.E2E_ADMIN_USERNAME || 'admin';
const adminPassword = process.env.E2E_ADMIN_PASSWORD || 'demo12345';

test('multiple ingredients, live suggestions, essential status and strict filtering', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('مواد از تو');
  const tomato = page.locator('.ingredient-chip').filter({ hasText: 'گوجه‌فرنگی' });
  const egg = page.locator('.ingredient-chip').filter({ hasText: 'تخم‌مرغ' });
  await tomato.click(); await egg.click();
  await expect(tomato).toHaveAttribute('aria-pressed', 'true');
  await expect(egg).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'پیشنهاد غذا', exact: true }).click();
  await expect(page.locator('.recipe-card').first().locator('h3')).toContainText('املت');
  await expect(page.locator('.recipe-card').first().locator('.match-info')).toContainText('همه مواد ضروری را داری');
  await page.getByLabel('فیلتر مواد کم‌دار').selectOption('0');
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await page.reload();
  await expect(page.locator('.ingredient-chip').filter({ hasText: 'تخم‌مرغ' })).toHaveAttribute('aria-pressed', 'true');
});

test('search, sections, diet filters and external recipe provenance', async ({ page }) => {
  await page.goto('/');
  await page.getByLabel('جست‌وجوی غذاها', { exact: true }).fill('قورمه');
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await expect(page.locator('.recipe-card h3')).toContainText('قورمه');
  await page.getByRole('link', { name: 'نوشیدنی', exact: true }).click();
  await expect(page).toHaveURL(/collection\/drinks/);
  await expect(page.locator('.recipe-card')).toHaveCount(3);
  await page.getByRole('button', { name: 'سبک و رژیمی', exact: true }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await expect(page.locator('.recipe-card h3')).toContainText('خیار');
  await page.getByRole('button', { name: 'بدون شکر افزوده', exact: true }).click();
  await expect(page.locator('.recipe-card')).toHaveCount(3);
  await page.goto('/recipes/cucumber-water');
  await expect(page.locator('.recipe-source a')).toHaveAttribute('href', 'https://www.threelittlechickpeas.com/lemon-mint-and-cucumber-water/');
  await expect(page.locator('.detail-times')).toContainText('استراحت');
  await expect(page.locator('.detail-times')).toContainText('بدون پخت');
});

test('serving amounts, saved recipes, shopping list, step completion and focus mode', async ({ page }) => {
  await page.goto('/recipes/tahchin');
  await page.getByRole('button', { name: 'افزایش تعداد نفرات', exact: true }).click();
  await expect(page.locator('.detail-ingredient').first().locator('.ingredient-amount')).toContainText('۵۰۰');
  await page.getByRole('button', { name: 'ذخیره دستور', exact: true }).click();
  await expect(page.getByRole('button', { name: 'ذخیره شده', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.goto('/saved');
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await page.reload();
  await expect(page.locator('.recipe-card')).toHaveCount(1);
  await page.goto('/recipes/tahchin');
  await page.getByRole('button', { name: 'مواد کم‌دار به لیست خرید', exact: true }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.locator('.shopping-item')).toHaveCount(6);
  await page.locator('.shopping-check').first().click();
  await expect(page.locator('.shopping-item').first()).toHaveClass(/done/);
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('button', { name: 'تکمیل مرحله ۱', exact: true }).click();
  await expect(page.getByRole('button', { name: 'برگرداندن مرحله ۱', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'شروع آشپزی', exact: true }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.getByRole('button', { name: 'انجام شد؛ مرحله بعد', exact: true }).click();
  await expect(page.getByRole('dialog').getByRole('heading', { level: 3 })).toHaveText('برنج نیم‌پز');
  await page.keyboard.press('Escape');
});

test('mobile navigation, all sections and no page-wide horizontal overflow', async ({ browser }) => {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();
  await page.goto(`${process.env.E2E_BASE_URL || 'http://127.0.0.1:3000'}/`);
  await page.getByRole('button', { name: 'باز کردن منو', exact: true }).click();
  for (const label of ['آشپزی ایرانی', 'غذای فرنگی', 'دسر', 'نوشیدنی', 'پیش‌غذا']) await expect(page.locator('.mobile-nav').getByRole('link', { name: label, exact: true })).toBeVisible();
  await page.locator('.mobile-nav').getByRole('link', { name: 'دسر', exact: true }).click();
  await expect(page).toHaveURL(/collection\/dessert/);
  await expect(page.locator('.recipe-card')).toHaveCount(3);
  for (const width of [320, 360, 390, 768, 1024]) {
    await page.setViewportSize({ width, height: 844 });
    await page.goto(`${process.env.E2E_BASE_URL || 'http://127.0.0.1:3000'}/`);
    await expect(page.locator('.ingredient-chip').first()).toBeVisible();
    const sizes = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }));
    expect(sizes.scroll).toBeLessThanOrEqual(sizes.client + 1);
  }
  await context.close();
});

test('admin creates, edits, persists and deletes a recipe', async ({ page, request }) => {
  const title = `دستور آزمایشی E2E ${Date.now()}`;
  const editedTitle = `${title} ویرایش`;
  let createdId = '';
  let token = '';
  try {
    await page.goto('/admin');
    await page.getByLabel('نام کاربری', { exact: true }).fill(adminUser);
    await page.getByLabel('رمز عبور', { exact: true }).fill(adminPassword);
    await page.getByRole('button', { name: 'ورود به مدیریت', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'مدیریت دستورهای غذایی', exact: true })).toBeVisible();
    token = await page.evaluate(() => sessionStorage.getItem('zaferoon-token') || '');
    await page.getByRole('button', { name: 'دستور جدید', exact: true }).click();
    const dialog = page.getByRole('dialog');
    await dialog.getByLabel(/نام غذا/).fill(title);
    await dialog.getByLabel('بخش اصلی', { exact: true }).selectOption('international');
    await dialog.getByLabel('دسته‌بندی', { exact: true }).selectOption('world');
    await dialog.getByLabel(/معرفی غذا/).fill('این یک دستور آزمایشی برای بررسی عملکرد واقعی پنل مدیریت است.');
    await dialog.getByRole('textbox', { name: 'عنوان مرحله ۱', exact: true }).fill('آماده‌سازی آزمایشی');
    await dialog.getByRole('textbox', { name: 'توضیح مرحله ۱', exact: true }).fill('مواد را آماده و مخلوط کنید. این دستور صرفاً برای تست است.');
    const createdResponse = page.waitForResponse(r => r.url().endsWith('/api/recipes') && r.request().method() === 'POST' && r.status() === 201);
    await dialog.getByRole('button', { name: 'ذخیره دستور', exact: true }).click();
    createdId = (await (await createdResponse).json()).id;
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await expect(page.getByRole('row').filter({ hasText: title })).toHaveCount(1);
    await page.reload();
    await expect(page.getByRole('row').filter({ hasText: title })).toHaveCount(1);
    await page.getByRole('button', { name: `ویرایش ${title}`, exact: true }).click();
    await page.getByRole('dialog').getByLabel(/نام غذا/).fill(editedTitle);
    await page.getByRole('dialog').getByLabel('تعداد نفرات', { exact: true }).fill('2');
    await page.getByRole('dialog').getByRole('button', { name: 'ذخیره دستور', exact: true }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await page.reload();
    await expect(page.getByRole('row').filter({ hasText: editedTitle })).toContainText('۲ نفر');
    await page.goto(`/recipes/${createdId}`);
    await expect(page.getByRole('heading', { level: 1 })).toHaveText(editedTitle);
    await page.goto('/admin');
    await page.getByRole('button', { name: `حذف ${editedTitle}`, exact: true }).click();
    await page.getByRole('dialog').getByRole('button', { name: 'بله، حذف کن', exact: true }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await expect(page.getByRole('row').filter({ hasText: editedTitle })).toHaveCount(0);
    await page.reload();
    await expect(page.getByRole('row').filter({ hasText: editedTitle })).toHaveCount(0);
    expect((await request.get(`/api/recipes/${createdId}`)).status()).toBe(404);
  } finally {
    if (createdId && token) await request.delete(`/api/recipes/${createdId}`, { headers: { Authorization: `Bearer ${token}` } });
  }
});

test('admin API is protected; upload validates image signatures', async ({ request }) => {
  expect((await request.post('/api/recipes', { data: {} })).status()).toBe(401);
  const login = await request.post('/api/auth/login', { data: { username: adminUser, password: adminPassword } });
  expect(login.ok()).toBeTruthy();
  const token = (await login.json()).token;
  const headers = { Authorization: `Bearer ${token}` };
  const invalid = await request.post('/api/uploads', { headers, multipart: { image: { name: 'fake.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('<html>not an image</html>') } } });
  expect(invalid.status()).toBe(400);
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRngAAAAASUVORK5CYII=', 'base64');
  const valid = await request.post('/api/uploads', { headers, multipart: { image: { name: 'pixel.png', mimeType: 'image/png', buffer: png } } });
  expect(valid.status()).toBe(201);
  const url = (await valid.json()).url;
  expect(url).toMatch(/^\/images\/uploads\/[\w-]+\.png$/);
  expect((await request.get(url)).status()).toBe(200);
  await request.post('/api/auth/logout', { headers });
  expect((await request.get('/api/auth/me', { headers })).status()).toBe(401);
});

test('no uncaught browser errors while loading routes and assets', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  for (const route of ['/', '/collection/international', '/collection/dessert', '/collection/drinks', '/collection/appetizer', '/saved', '/admin', '/recipes/panna-cotta', '/missing-page']) {
    await page.goto(route);
    await page.waitForLoadState('networkidle');
  }
  expect(errors).toEqual([]);
});
