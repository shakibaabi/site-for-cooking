import { test, expect } from '@playwright/test';
import { evaluate } from '../src/lib/utils';
import { matchRecipe } from '../server/domain.js';
import { ingredients, recipes } from '../server/seed.js';

test('browser and server matching stay identical for every recipe and pantry combination', () => {
  const pantries = [[], ['tomato', 'egg'], ['strawberry', 'banana', 'orange-juice'], ['oil', 'salt'], ingredients.map(i => i.id), ['rice', 'chicken', 'onion', 'yogurt', 'saffron']];
  for (const recipe of recipes) {
    for (const pantry of pantries) {
      for (const basics of [true, false]) expect(evaluate(recipe, pantry, ingredients, basics)).toEqual(matchRecipe(recipe, pantry, basics));
    }
  }
});
