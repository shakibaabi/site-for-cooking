import { z } from 'zod';
import { categories, ingredients, collections } from './seed.js';

export const normalize = (value = '') => String(value).toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200c\u200d\u0640]/g, '').replace(/\s+/g, '').trim();
export const basicIds = ingredients.filter(i => i.group === 'basics').map(i => i.id);

export function matchRecipe(recipe, pantry, assumeBasics = true) {
  const selected = new Set(pantry);
  const available = new Set([...selected, ...(assumeBasics ? basicIds : ['water'])]);
  const required = recipe.ingredients.filter(i => i.essential);
  const availableEssential = required.filter(i => available.has(i.ingredientId));
  const missingEssential = required.filter(i => !available.has(i.ingredientId));
  const missingOptional = recipe.ingredients.filter(i => !i.essential && !available.has(i.ingredientId));
  const core = required.filter(i => !basicIds.includes(i.ingredientId));
  const coreMatched = core.filter(i => available.has(i.ingredientId));
  return {
    availableEssential, missingEssential, missingOptional,
    percent: core.length ? Math.round(coreMatched.length / core.length * 100) : 100,
    matchedCore: coreMatched.length,
    ready: missingEssential.length === 0,
  };
}

export function suggestRecipes(recipes, pantry, { assumeBasics = true, maxMissing = Infinity } = {}) {
  return recipes.map(recipe => ({ ...recipe, match: matchRecipe(recipe, pantry, assumeBasics) }))
    .filter(recipe => recipe.match.matchedCore > 0 && recipe.match.missingEssential.length <= maxMissing)
    .sort((a, b) => Number(b.match.ready) - Number(a.match.ready) || b.match.percent - a.match.percent || b.match.matchedCore - a.match.matchedCore || (a.prepTime + a.cookTime + (a.restTime || 0)) - (b.prepTime + b.cookTime + (b.restTime || 0)));
}

const ingredientIds = new Set(ingredients.map(i => i.id));
const safeImage = z.string().min(1).max(2048).refine(value => {
  if (/^\/images\/[a-zA-Z0-9/_\-.]+$/.test(value) && !value.includes('..')) return true;
  try { return new URL(value).protocol === 'https:'; } catch { return false; }
}, 'آدرس تصویر باید از /images/ یا یک آدرس HTTPS معتبر باشد.');

export const recipeSchema = z.object({
  title: z.string().trim().min(2).max(100),
  subtitle: z.string().trim().max(160).default(''),
  description: z.string().trim().min(10).max(3000),
  category: z.enum(categories.map(c => c.id)),
  section: z.enum(collections.map(c => c.id)).default('iranian'),
  restTime: z.number().int().min(0).max(2880).default(0),
  sourceName: z.string().trim().max(150).default(''),
  sourceUrl: z.string().max(2048).refine(v => { if (!v) return true; try { return new URL(v).protocol === 'https:'; } catch { return false; } }, 'لینک منبع باید HTTPS معتبر باشد.').default(''),
  sourceNote: z.string().trim().max(1500).default(''),
  image: safeImage,
  tags: z.array(z.string().trim().min(1).max(30)).max(8).default([]),
  prepTime: z.number().int().min(0).max(1440),
  cookTime: z.number().int().min(0).max(1440),
  servings: z.number().int().min(1).max(50),
  difficulty: z.enum(['آسان', 'متوسط', 'حرفه‌ای']),
  featured: z.boolean().default(false),
  ingredients: z.array(z.object({
    ingredientId: z.string().refine(id => ingredientIds.has(id), 'ماده اولیه نامعتبر است.'),
    amount: z.number().positive().max(100000),
    unit: z.string().trim().min(1).max(40),
    essential: z.boolean(),
    note: z.string().trim().max(250).default(''),
  })).min(1).max(60).refine(rows => new Set(rows.map(i => i.ingredientId)).size === rows.length, 'ماده اولیه تکراری است.').refine(rows => rows.some(i => i.essential), 'حداقل یک ماده ضروری لازم است.'),
  steps: z.array(z.object({ title: z.string().trim().min(2).max(100), text: z.string().trim().min(10).max(2000) })).min(1).max(30),
  tips: z.string().trim().max(2000).default(''),
}).superRefine((data, ctx) => {
  if (categories.find(c => c.id === data.category)?.section !== data.section) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['category'], message: 'دسته‌بندی با بخش انتخاب‌شده سازگار نیست.' });
  if (data.prepTime + data.cookTime + data.restTime === 0) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['prepTime'], message: 'زمان کل باید بیشتر از صفر باشد.' });
});
