import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { recipes as seeds } from './seed.js';

// Keep persistence behind this boundary. Replace this class with a SQL repository
// without changing route contracts or the frontend.
export class RecipeRepository {
  constructor(file) {
    this.file = file;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (!fs.existsSync(file)) this.write({ version: 1, recipes: seeds });
    this.data = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (this.data.version !== 1 || !Array.isArray(this.data.recipes)) throw new Error('Invalid recipe data store.');
  }
  write(data) {
    const temporary = `${this.file}.tmp`;
    fs.writeFileSync(temporary, JSON.stringify(data, null, 2), { mode: 0o600 });
    fs.renameSync(temporary, this.file);
  }
  list() { return structuredClone(this.data.recipes); }
  find(id) { return structuredClone(this.data.recipes.find(r => r.id === id)); }
  create(recipe) {
    const newRecipe = { ...recipe, id: crypto.randomUUID(), createdAt: new Date().toISOString() };
    const next = { ...this.data, recipes: [newRecipe, ...this.data.recipes] };
    this.write(next); this.data = next;
    return structuredClone(newRecipe);
  }
  update(id, recipe) {
    const old = this.data.recipes.find(r => r.id === id);
    if (!old) return null;
    const updated = { ...recipe, id, createdAt: old.createdAt, updatedAt: new Date().toISOString() };
    const next = { ...this.data, recipes: this.data.recipes.map(r => r.id === id ? updated : r) };
    this.write(next); this.data = next;
    return structuredClone(updated);
  }
  remove(id) {
    if (!this.data.recipes.some(r => r.id === id)) return false;
    const next = { ...this.data, recipes: this.data.recipes.filter(r => r.id !== id) };
    this.write(next); this.data = next;
    return true;
  }
}
