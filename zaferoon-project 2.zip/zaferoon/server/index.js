import 'dotenv/config';
import express from 'express';
import { createServer } from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import { fileURLToPath } from 'node:url';
import { RecipeRepository } from './repository.js';
import { categories, ingredients, collections } from './seed.js';
import { normalize, recipeSchema, suggestRecipes } from './domain.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const compiledDemo = process.argv.includes('--demo');
const production = process.argv.includes('--production') || process.env.NODE_ENV === 'production';
const username = process.env.ADMIN_USERNAME || 'admin';
const password = process.env.ADMIN_PASSWORD || 'demo12345';
if (production && !compiledDemo && (!process.env.ADMIN_PASSWORD || password.length < 12 || password === 'demo12345')) {
  throw new Error('Production requires ADMIN_PASSWORD with at least 12 characters, different from the demo password.');
}
const passwordHash = await bcrypt.hash(password, 12);
const repo = new RecipeRepository(path.join(root, 'data', 'store.json'));
const sessions = new Map();
const attempts = new Map();
const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});
app.use('/api', express.json({ limit: '500kb' }));
app.use('/api', (_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

function auth(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer /, '');
  const session = token && sessions.get(token);
  if (!session || session.expires < Date.now()) {
    if (token) sessions.delete(token);
    return res.status(401).json({ error: 'لطفاً دوباره وارد پنل مدیریت شوید.' });
  }
  req.authToken = token;
  next();
}
const cleanSessions = setInterval(() => {
  for (const [token, session] of sessions) if (session.expires < Date.now()) sessions.delete(token);
  for (const [ip, attempt] of attempts) if (attempt.reset < Date.now()) attempts.delete(ip);
}, 60000);
cleanSessions.unref();

app.get('/api/health', (_req, res) => res.json({ ok: true, mode: production && !compiledDemo ? 'production' : 'demo' }));
app.get('/api/bootstrap', (_req, res) => res.json({ ingredients, categories, collections, recipes: repo.list(), demo: (!production || compiledDemo) && username === 'admin' && password === 'demo12345' }));
app.get('/api/recipes', (req, res) => {
  let list = repo.list();
  if (req.query.section) list = list.filter(r => r.section === req.query.section);
  if (req.query.category) list = list.filter(r => r.category === req.query.category);
  if (req.query.q) {
    const q = normalize(req.query.q);
    list = list.filter(r => normalize(`${r.title} ${r.description} ${r.tags.join(' ')}`).includes(q));
  }
  res.json(list);
});
app.get('/api/recipes/:id', (req, res) => {
  const recipe = repo.find(req.params.id);
  if (!recipe) return res.status(404).json({ error: 'این دستور پیدا نشد.' });
  res.json(recipe);
});
app.post('/api/suggestions', (req, res) => {
  const { pantry, assumeBasics = true, maxMissing } = req.body || {};
  const validIds = new Set(ingredients.map(i => i.id));
  if (!Array.isArray(pantry) || pantry.length > 100 || !pantry.every(id => typeof id === 'string' && validIds.has(id)) || typeof assumeBasics !== 'boolean' || (maxMissing !== undefined && (!Number.isInteger(maxMissing) || maxMissing < 0 || maxMissing > 60))) {
    return res.status(400).json({ error: 'مواد انتخاب‌شده معتبر نیستند.' });
  }
  res.json(suggestRecipes(repo.list(), pantry, { assumeBasics, maxMissing }));
});
app.post('/api/auth/login', async (req, res, next) => {
  try {
    const ip = req.ip;
    const previous = attempts.get(ip);
    const state = previous && previous.reset > Date.now() ? previous : { count: 0, reset: Date.now() + 15 * 60 * 1000 };
    if (state.count >= 10) return res.status(429).json({ error: 'تعداد تلاش‌ها زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید.' });
    state.count += 1; attempts.set(ip, state);
    const { username: inputUser, password: inputPassword } = req.body || {};
    if (typeof inputPassword !== 'string' || inputPassword.length > 200 || typeof inputUser !== 'string') return res.status(400).json({ error: 'نام کاربری و رمز را وارد کنید.' });
    const matches = await bcrypt.compare(inputPassword, passwordHash);
    if (inputUser !== username || !matches) return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است.' });
    attempts.delete(ip);
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, { expires: Date.now() + 8 * 60 * 60 * 1000 });
    res.json({ token, username });
  } catch (error) { next(error); }
});
app.get('/api/auth/me', auth, (_req, res) => res.json({ username }));
app.post('/api/auth/logout', auth, (req, res) => { sessions.delete(req.authToken); res.json({ ok: true }); });

const validate = (body, res) => {
  const parsed = recipeSchema.safeParse(body);
  if (!parsed.success) {
    res.status(400).json({ error: 'اطلاعات دستور کامل یا معتبر نیست.', details: parsed.error.issues.map(i => `${i.path.join('.')}: ${i.message}`) });
    return null;
  }
  return parsed.data;
};
app.post('/api/recipes', auth, (req, res) => { const data = validate(req.body, res); if (data) res.status(201).json(repo.create(data)); });
app.put('/api/recipes/:id', auth, (req, res) => {
  const data = validate(req.body, res); if (!data) return;
  const updated = repo.update(req.params.id, data);
  if (!updated) return res.status(404).json({ error: 'دستور پیدا نشد.' });
  res.json(updated);
});
app.delete('/api/recipes/:id', auth, (req, res) => {
  if (!repo.remove(req.params.id)) return res.status(404).json({ error: 'دستور پیدا نشد.' });
  res.json({ ok: true });
});

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 6 * 1024 * 1024, files: 1 } });
app.post('/api/uploads', auth, upload.single('image'), (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: 'یک فایل تصویر انتخاب کنید.' });
  const b = file.buffer;
  let ext = '';
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) ext = '.jpg';
  else if (b.length > 8 && b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) ext = '.png';
  else if (b.length > 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') ext = '.webp';
  if (!ext) return res.status(400).json({ error: 'فقط تصاویر JPG، PNG و WebP مجازند.' });
  const directory = path.join(root, 'public', 'images', 'uploads');
  fs.mkdirSync(directory, { recursive: true });
  const filename = `${crypto.randomUUID()}${ext}`;
  fs.writeFileSync(path.join(directory, filename), b);
  res.status(201).json({ url: `/images/uploads/${filename}` });
});
app.use('/api', (_req, res) => res.status(404).json({ error: 'مسیر API پیدا نشد.' }));
app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(err.status || (err instanceof multer.MulterError ? 400 : 500)).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'حجم تصویر باید کمتر از ۶ مگابایت باشد.' : 'در پردازش درخواست خطایی رخ داد. دوباره تلاش کنید.' });
});

const server = createServer(app);
if (production) {
  const dist = path.join(root, 'dist');
  if (!fs.existsSync(path.join(dist, 'index.html'))) throw new Error('Run npm run build before npm start.');
  app.use('/images/uploads', express.static(path.join(root, 'public', 'images', 'uploads')));
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({ root, server: { middlewareMode: true, hmr: { server }, allowedHosts: true }, appType: 'spa' });
  app.use(vite.middlewares);
}
const port = Number(process.env.PORT || 3000);
server.listen(port, '0.0.0.0', () => console.log(`Zaferoon ${production && !compiledDemo ? 'production' : 'demo'} ready on http://0.0.0.0:${port}`));
