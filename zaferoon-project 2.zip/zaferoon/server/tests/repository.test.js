import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { RecipeRepository } from '../repository.js';
import { recipes } from '../seed.js';

test('Repository seeds once, persists CRUD and returns defensive clones', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zaferoon-test-'));
  try {
    const file = path.join(dir, 'store.json');
    const repo = new RecipeRepository(file);
    assert.equal(repo.list().length, 24);
    const input = structuredClone(recipes[0]); delete input.id;
    input.title = 'دستور آزمایشی';
    const created = repo.create(input);
    assert.ok(created.id);
    assert.equal(repo.list().length, 25);
    assert.equal(new RecipeRepository(file).find(created.id).title, input.title);
    const clone = repo.find(created.id); clone.title = 'changed only in memory';
    assert.equal(repo.find(created.id).title, input.title);
    repo.update(created.id, { ...input, title: 'ویرایش آزمایشی' });
    assert.equal(new RecipeRepository(file).find(created.id).title, 'ویرایش آزمایشی');
    assert.equal(repo.remove(created.id), true);
    assert.equal(repo.remove(created.id), false);
    assert.equal(repo.update('does-not-exist', input), null);
    assert.equal(new RecipeRepository(file).list().length, 24);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
