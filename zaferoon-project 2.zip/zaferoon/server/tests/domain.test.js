import test from 'node:test';
import assert from 'node:assert/strict';
import { normalize, matchRecipe, suggestRecipes, recipeSchema } from '../domain.js';
import { recipes, ingredients, collections } from '../seed.js';

const omelet = recipes.find(r => r.id === 'omelet');
test('Persian search normalizes Arabic letters, whitespace and ZWNJ', () => {
  assert.equal(normalize('سيب زميني'), normalize('سیب‌زمینی'));
  assert.equal(normalize('کوكو'), normalize('کوکو'));
});
test('Every seeded recipe validates and references real catalog entries', () => {
  assert.equal(recipes.length, 24);
  const ids = new Set(ingredients.map(i => i.id));
  const recipeIds = new Set();
  for (const recipe of recipes) {
    assert.ok(recipeSchema.safeParse(recipe).success, recipe.id);
    assert.ok(!recipeIds.has(recipe.id)); recipeIds.add(recipe.id);
    recipe.ingredients.forEach(row => assert.ok(ids.has(row.ingredientId)));
  }
  for (const collection of collections) assert.ok(recipes.filter(r => r.section === collection.id).length >= 3);
});
test('Multiple pantry items are matched together and basics can be assumed', () => {
  const result = matchRecipe(omelet, ['tomato', 'egg'], true);
  assert.equal(result.percent, 100); assert.equal(result.ready, true);
  assert.equal(result.missingEssential.length, 0);
});
test('Unselected mandatory basic ingredients remain missing when assumption is off', () => {
  const result = matchRecipe(omelet, ['tomato', 'egg'], false);
  assert.equal(result.ready, false);
  assert.ok(result.missingEssential.some(i => i.ingredientId === 'salt'));
  assert.ok(result.missingEssential.some(i => i.ingredientId === 'oil'));
});
test('Optional ingredients do not prevent a complete essential match', () => {
  const kuku = recipes.find(r => r.id === 'kuku-sabzi');
  const result = matchRecipe(kuku, ['herbs-kuku', 'egg']);
  assert.equal(result.ready, true);
  assert.ok(result.missingOptional.some(i => i.ingredientId === 'walnut'));
});
test('Ready recipes appear first and strict mode returns only complete recipes', () => {
  const list = suggestRecipes(recipes, ['egg', 'tomato']);
  assert.equal(list[0].id, 'omelet');
  const strict = suggestRecipes(recipes, ['egg', 'tomato'], { maxMissing: 0 });
  assert.ok(strict.length > 0);
  assert.ok(strict.every(r => r.match.missingEssential.length === 0));
});
test('No pantry and basic-only pantry do not produce unrelated results', () => {
  assert.deepEqual(suggestRecipes(recipes, []), []);
  assert.deepEqual(suggestRecipes(recipes, ['water', 'salt']), []);
});
test('Matching supports drinks and desserts, not just Persian meals', () => {
  const result = suggestRecipes(recipes, ['strawberry', 'banana', 'orange-juice']);
  assert.equal(result[0].id, 'strawberry-smoothie');
  assert.equal(result[0].match.ready, true);
});
test('No-cook recipes, source metadata, resting time and decimal amounts are accepted', () => {
  const recipe = recipes.find(r => r.id === 'cucumber-water');
  assert.ok(recipeSchema.safeParse(recipe).success);
  assert.equal(recipe.cookTime, 0); assert.equal(recipe.restTime, 60);
  assert.equal(recipe.ingredients.find(i => i.ingredientId === 'cucumber').amount, 0.5);
});
test('Unsafe images, invalid quantities, duplicated ingredients and mismatched sections fail validation', () => {
  assert.equal(recipeSchema.safeParse({ ...omelet, image: 'javascript:alert(1)' }).success, false);
  assert.equal(recipeSchema.safeParse({ ...omelet, image: '/images/../server/index.js' }).success, false);
  assert.equal(recipeSchema.safeParse({ ...omelet, servings: 0 }).success, false);
  assert.equal(recipeSchema.safeParse({ ...omelet, section: 'drinks' }).success, false);
  assert.equal(recipeSchema.safeParse({ ...omelet, ingredients: [omelet.ingredients[0], omelet.ingredients[0]] }).success, false);
});
